
import './App.css';
import { AiOutlineMenu } from 'react-icons/ai';
import { BsClock } from 'react-icons/bs';
import { BsThreeDotsVertical } from 'react-icons/bs';
import { FaUserCircle } from 'react-icons/fa';

import AllRoutes from './RouterPage';
import Dashboard from './Dashbord/Dashboard';


function App() {
 return(
<>

   <Dashboard/>
   
</>
 );
}
export default App;