import  React ,{useState} from 'react';
import Box from '@mui/material/Box';
import TextField from '@mui/material/TextField';
import './Menu.css'

export default function Menu() {
    const [name, setName] = useState('')
    const [itemname, setItemname] = useState('')
    const [price, setPrice] = useState('')
    const [quantity, setQuantity] = useState('')

    return (
        <div className='form-box'>
            <Box
                component="form"
                sx={{
                    '& .MuiTextField-root': { m: 1, width: '50ch' },
                }}
                noValidate
                autoComplete="off"
            >
                <div>
                    <TextField
                        required
                        id="outlined-required"
                        label="Item Name"
                        onChange={(e) => {
                            setName(e.target.value);
                          }}
                    />
                    <TextField
                        required
                        id="outlined-required"
                        label="Item Price"
                        onChange={(e) => {
                            setItemname(e.target.value);
                          }}
                    />
                    <TextField
                        required
                        id="outlined-required"
                        label="Quantity"
                        onChange={(e) => {
                            setPrice(e.target.value);
                          }}
                    />
                    <TextField
                        required
                        id="outlined-required"
                        label="Required"
                        onChange={(e) => {
                            setQuantity(e.target.value);
                          }}
                    />

                   
                </div>

            </Box>
            <button type='button' onClick={()=>
                console.log("janmejay")
            }>Save</button>
        </div>
    );
}