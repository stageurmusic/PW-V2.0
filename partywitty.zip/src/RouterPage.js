
import React from "react";

import { BrowserRouter as Router, Routes, Route, Link } from "react-router-dom";
import Dashboard from "./Dashbord/Dashboard";
import Menu from "./Menu/Menu";

function Routerpage() {
    return (
        <Router>
            <div className="router-page">
                <Routes>
                    <Route exact path="/" element={<Dashboard />}></Route>
                </Routes>
                <Routes>
                    <Route exact path="/menu" element={<Menu />}></Route>
                </Routes>
            </div>
        </Router>
    );
}
export default Routerpage;
